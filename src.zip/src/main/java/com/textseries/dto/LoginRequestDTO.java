package com.textseries.dto;

import lombok.Data;

@Data
public class LoginRequestDTO {

    private String studentName;
    private String password;
}