package com.textseries.service;

import com.textseries.config.JwtUtil;
import com.textseries.dto.LoginRequestDTO;
import com.textseries.model.User;
import com.textseries.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository repo;
    private final JwtUtil jwtUtil;

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AuthService(UserRepository repo, JwtUtil jwtUtil) {
        this.repo = repo;
        this.jwtUtil = jwtUtil;
    }

    // ✅ Register
    public String register(User user) {

        user.setPassword(encoder.encode(user.getPassword()));

        if (user.getRole() == null) {
            user.setRole("USER");
        }

        repo.save(user);

        return "User registered successfully";
    }

    // ✅ Login
    public String login(LoginRequestDTO request) {

        User user = repo.findByStudentName(request.getStudentName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!encoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return jwtUtil.generateToken(user.getStudentName(), user.getRole());
    }
}