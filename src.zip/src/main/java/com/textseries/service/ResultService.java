package com.textseries.service;

import com.textseries.dto.AnalysisDTO;
import com.textseries.dto.SubmitRequestDTO;
import com.textseries.model.Question;
import com.textseries.model.Result;
import com.textseries.repository.QuestionRepository;
import com.textseries.repository.ResultRepository;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ResultService {

	private final QuestionRepository questionRepo;
	private final ResultRepository resultRepo;

	public ResultService(QuestionRepository questionRepo, ResultRepository resultRepo) {
		this.questionRepo = questionRepo;
		this.resultRepo = resultRepo;
	}

	// 🧠 Submit Test
	public Result calculateResult(SubmitRequestDTO request) {

		LocalDateTime now = LocalDateTime.now();
		long seconds = Duration.between(request.getStartTime(), now).toSeconds();

		System.out.println("ANSWERS: " + request.getAnswers());

		System.out.println("START: " + request.getStartTime());
		System.out.println("NOW: " + now);
		System.out.println("SECONDS: " + seconds);

		int correct = 0;
		int wrong = 0;

		// ⏱️ 5 min = 300 sec
		Map<Long, String> answers = request.getAnswers() != null ? request.getAnswers() : Map.of();

		List<Question> allQuestions = questionRepo.findByCategory("java");

		for (Question q : allQuestions) {

			String userAns = answers.get(q.getId());

			if (userAns == null) {
				wrong++;
			} else if (q.getCorrectAnswer().equals(userAns)) {
				correct++;
			} else {
				wrong++;
			}
		}

		if (seconds > 300) {
			System.out.println("⚠️ Late submission");
		}

		double score = correct - (wrong * 0.25);

		Result result = Result.builder().studentName(request.getUsername()).score(score).totalQuestions(correct + wrong)
				.correctAnswers(correct).wrongAnswers(wrong).category("java").submittedAt(LocalDateTime.now()).build();

		return resultRepo.save(result);
	}

	public long totalAttempts() {
		return resultRepo.count();
	}

	public List<AnalysisDTO> getAnalysis(Map<Long, String> answers) {

	    Map<Long, String> safeAnswers = answers != null ? answers : Map.of();

	    List<AnalysisDTO> list = new ArrayList<>();

	    List<Question> allQuestions = questionRepo.findByCategory("java");

	    for (Question q : allQuestions) {

	        String userAns = safeAnswers.get(q.getId());

	        if (userAns == null || !q.getCorrectAnswer().equals(userAns)) {

	            list.add(new AnalysisDTO(
	                q.getQuestion(),
	                q.getOptionA(),
	                q.getOptionB(),
	                q.getOptionC(),
	                q.getOptionD(),
	                q.getCorrectAnswer(),
	                userAns == null ? "Not Answered" : userAns
	            ));
	        }
	    }

	    return list;
	}

	// 🏆 Leaderboard
	public List<Result> getLeaderboard() {
		return resultRepo.findBestScores();
	}

	public double getAverageScore() {
		return resultRepo.findAll().stream().mapToDouble(Result::getScore) // ✅ correct
				.average().orElse(0);
	}

	public Result getTopper() {
		return resultRepo.findAll().stream().max((a, b) -> Double.compare(a.getScore(), b.getScore())) // ✅
				.orElse(null);
	}
	
	public List<Result> getRecent() {
	    return resultRepo.findTop5ByOrderBySubmittedAtDesc();
	}

	// 📜 User History
	public List<Result> getUserHistory(String studentName) {
		return resultRepo.findByStudentNameOrderBySubmittedAtDesc(studentName);
	}
}