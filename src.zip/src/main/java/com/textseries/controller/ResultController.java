package com.textseries.controller;

import com.textseries.dto.AnalysisDTO;
import com.textseries.dto.SubmitRequestDTO;
import com.textseries.model.Result;
import com.textseries.repository.ResultRepository;
import com.textseries.service.ResultService;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/result")

public class ResultController {

    private final ResultService service;

    public ResultController(ResultService service) {
        this.service = service;
    }
    

    // ✅ Submit
    @PostMapping
    public Result submit(@RequestBody SubmitRequestDTO request) {
    	 System.out.println("🔥 RESULT API HIT");
    	return service.calculateResult(request);
    }

    // 🏆 Leaderboard
    @GetMapping("/leaderboard")
    public List<Result> leaderboard() {
        return service.getLeaderboard();
    }
    
    @PostMapping("/analysis")
    public List<AnalysisDTO> analysis(@RequestBody SubmitRequestDTO request) {
        return service.getAnalysis(request.getAnswers());
    }

    // 📜 History
    @GetMapping("/history")
    public List<Result> history(Authentication auth) {
        String studentName = auth.getName();  
        return service.getUserHistory(studentName);
    }
    
    
    
    @GetMapping("/admin/analytics")
    public long totalAttempts() {
        return service.totalAttempts();
    }
    
    @GetMapping("/admin/avg-score")
    public double avgScore() {
        return service.getAverageScore();
    }

    @GetMapping("/admin/topper")
    public Result topper() {
        return service.getTopper();
    }
    
    @GetMapping("/admin/recent")
    public List<Result> getRecent() {
        return service.getRecent(); // 👈 service use करो
    }
    
    
}