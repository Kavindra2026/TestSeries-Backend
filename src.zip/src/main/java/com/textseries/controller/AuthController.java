package com.textseries.controller;

import com.textseries.dto.AuthResponseDTO;
import com.textseries.dto.LoginRequestDTO;
import com.textseries.model.User;
import com.textseries.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    // ✅ Register
    @PostMapping("/register")
    public String register(@RequestBody User user) {
        return service.register(user);
    }

    // ✅ Login
    @PostMapping("/login")
    public AuthResponseDTO login(@RequestBody LoginRequestDTO request) {
        String token = service.login(request); 
        return new AuthResponseDTO(token);
    }
}